exports.handler = (event, context, callback) => {
    var aws = require('aws-sdk');
    aws.config.update({
        region: "us-east-1"
    });
    const doc = require('dynamodb-doc');
    var dynamo = new aws.DynamoDB.DocumentClient();
    var s3 = new aws.S3({ apiVersion: '2006-03-01' });
    const bucket = 'influentmetrics';
    var id, action;
    
    switch (event.httpMethod) {
        case 'OPTIONS':
            callback(null, {
                statusCode: '200',
                body: '',
                headers: {  
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'X-Requested-With, X-CSRF-Token'
                }
            });
            break;
        case 'GET':
            action = event.queryStringParameters.a;
            id = event.queryStringParameters.o;
            // console.log({query:event.queryStringParameters});
            switch (action) {
                case "getConfig":
                    getConfig(id, callback, sendResponse);
                    break;
                case "login":
                    getAccountConfig(authenticate, {
                        username:event.queryStringParameters.username,
                        password:event.queryStringParameters.password
                    });
                    break;
                case "updateConfig":
                    break;
                case "getProfiles":
                    // get listing of profiles grouped into buckets, along with bucket metrics
                    getConfig(id, callback, getProfiles);
                    break;
                case "getProfile":
                    // get profile details for a specific profile_id
                    getConfig(id, callback, getProfile);
                    break;
            }
            break;
        case 'POST':
            console.log({post_event:event});
            if (event.queryStringParameters) {
                console.log({foundQueryString:$input.body});
                event.data = event.body 
            } else {
                event.data = JSON.parse(event.body);
            }
            id = event.data.org;
            action = event.data.action;
            switch (action) {
                case "upload":
                    getConfig(id, callback, upload);
                    break;
                default:
                    delete(event.data.org);
                    getConfig(id, callback,updateConfig);
                    break;
            }
            break;
    }
    
    function getProfile(config, id) {
        var profile_id = event.queryStringParameters.p;
        var timestamp = event.queryStringParameters.t;

console.log('in getProfile.  profile_id='+profile_id);
        if (!profile_id) return;
        var query;
        if (timestamp) {
            query = {
                TableName: 'profile_' + id,
                ScanIndexForward:false,
                KeyConditionExpression: 'profile_id = :pid, #ts=:timestamp',
                ExpressionAttributeNames: {
                    '#ts': 'timestamp'
                },
                ExpressionAttributeValues: {
                    ':pid': profile_id,
                    ':timestamp': timestamp
                },
                Limit:1
            }
        } else {
            query = {
                TableName: 'profile_' + id,
                ScanIndexForward:false,
                KeyConditionExpression: 'profile_id = :pid',
                ExpressionAttributeValues: {
                    ':pid': profile_id,
                }
            }
        }
        dynamo.query(query, function(err,data) {
            if (err) {
                console.error("Unable to scan the table. Error JSON:", JSON.stringify(err, null, 2));
            } else {
  //              console.log(JSON.stringify({'query_result':data}));
                if (data.Items) {
                    sendResponse({profile:data});
                }
            }
        });
    }
    
    function queryProfiles(config, id, days, currentDay, profiles, callback, exclusiveStartKey) {
        // days: how many days to query
        // currentDay: current query counter
        var d = (new Date((new Date()).setDate((new Date()).getDate()-currentDay))).toLocaleDateString(undefined, { timeZone:config.settings.timezone }).split('/');
        var date = parseInt(d[2])*10000 + parseInt(d[0])*100 + parseInt(d[1]);
        var query = {
            TableName: 'profile_' + id,
            IndexName: 'timestamp_date-timestamp-index',
            KeyConditionExpression: 'timestamp_date = :ts_key',
            ExpressionAttributeValues: { ':ts_key':date },
            ScanIndexForward: 'false'
        };
        if (exclusiveStartKey)
            query.ExclusiveStartKey = exclusiveStartKey;
        dynamo.query(query, function(err,data) {
            if (err) {
                console.error("Unable to query the table. Error JSON:", JSON.stringify(err, null, 2));
            } else {
                profiles = profiles.concat(data.Items);
                console.log({query_results: {currentDay:currentDay,size:profiles.length}});
                if (data.lastEvaluatedKey) {
                    queryProfiles(config, id, days, currentDay, profiles, callback, data.lastEvaluatedKey);
                    console.log({paging_profiles:data.lastEvaluatedKey});
                } else {
                    currentDay++;
                    if (currentDay < days) {
                        queryProfiles(config, id, days, currentDay, profiles, callback);
                        console.log({paging_date_profiles:currentDay});
                    } else {
                        callback(profiles);
                    }
                }
            }
        });
    }

    function getProfiles(config, id) {
        var group = event.queryStringParameters.g;
        var date = event.queryStringParameters.d;
        console.log('in getProfiles: ' + date);
        var parse = require('./parse.js');
        var current_day = 0;
        if (date) {
          var d = { y:parseInt(date.substring(0,4)), m:parseInt(date.substring(4,6))-1, d:parseInt(date.substring(6,8)) };
          var fromTime = (new Date(d.y, d.m, d.d)).getTime();
          var d2 = (new Date()).toLocaleDateString(undefined, { timeZone:config.settings.timezone }).split('/');
          var toTime = (new Date(d2[2], d2[0]-1, d2[1])).getTime();
          current_day = Math.floor((toTime - fromTime)/(1000*60*60*24));
        }
        var days = 1;
        queryProfiles(config, id, days, current_day, [], function(profiles) {
            var getProfileViews = function(items) {
                const itemsInView = 50;
                var s = {}, p = {};
                var metrics = { sessions:0, visitors:0, views:0, matches:0, duration:0 };
                if (items) {
                  metrics.views = items.length;
                  items.map((k) => {
                    if (! s[k.profile_id]) { s[k.profile_id] = {}; }
                    if (! s[k.profile_id][k.counter_session]) { s[k.profile_id][k.counter_session] = {visitDuration:0}; }
                    s[k.profile_id][k.counter_session].visitDuration = s[k.profile_id][k.counter_session].visitDuration<k.session_duration ? k.session_duration : s[k.profile_id][k.counter_session].visitDuration;
                    if (! p[k.profile_id] || p[k.profile_id].timestamp<k.timestamp) p[k.profile_id]=k;
                  });
                }
                var profiles=[];
                Object.keys(s).map((k1) => {
                  p[k1].visitDuration = 0;
                  Object.keys(s[k1]).map((k2) => {
                    metrics.sessions++;
                    p[k1].visitDuration+=s[k1][k2].visitDuration;
                  });
                  metrics.duration+=p[k1].visitDuration;
                  profiles.push(p[k1]);
                });
                metrics.visitors = profiles.length;
                metrics.duration = metrics.sessions ? Math.floor(metrics.duration/metrics.sessions) : 0;
                var profilesViews_duration = profiles.slice();
                var profilesViews_visits = profiles.slice();
                var profilesViews_accessed = profiles.slice();
                profilesViews_duration.sort((a,b) => b.visitDuration-a.visitDuration);
                profilesViews_visits.sort((a,b) => b.counter_session-a.counter_session);
                profilesViews_accessed.sort((a,b) => b.timestamp - a.timestamp);
                var profilesViews = {metrics:metrics, profiles:{
                    duration:profilesViews_duration.slice(0,itemsInView),
                    visits:profilesViews_visits.slice(0,itemsInView),
                    accessed:profilesViews_accessed.slice(0,itemsInView)
                }};
                return profilesViews;
            };

            console.log({ending_getProfiles:profiles});
            var items = { };
            if (group=='all') {
                items.all = profiles;
            } else if (group) {
                items.groups = { };
                var p = profiles.filter((key) => { var code=JSON.parse(JSON.stringify(config.code.groups[group])); return (parse.inGroup(code,{profile:key}))[0] });
                items.groups[group] = getProfileViews(p);
            } else {
                items.groups = { };
                items.metrics = (getProfileViews(profiles)).metrics;
                Object.keys(config.code.groups).map((group)=> {
                    var p = profiles.filter((key) => { var code=JSON.parse(JSON.stringify(config.code.groups[group])); return (parse.inGroup(code,{profile:key}))[0] });
                    items.groups[group] = getProfileViews(p); 
                });
            }
console.log({ getProfiles_postItems:items });
            sendResponse({config:config,profiles:items});
        });
    }
    
    function upload(config, id) {
        console.log('in upload.');
        console.log({ body:event.body });
/*
        var multiparty = require('multiparty');
        var fs = require('fs');
        var form = new multiparty.Form();

        form.parse(req, function(err, fields, files) {
            res.write('received upload:\n\n');
            res.end(util.inspect({fields: fields, files: files}));
        });
        form.on('file', function(name,file) {
            console.log(file);
            console.log(name);
        });
*/

        sendResponse({uploaded:{success:true, body:event}});
    }
    
    function getConfig(id, fail, success) {
        var key = "dashboard/config/" + id + ".json";
        const params = { Bucket: bucket, Key: key };
        s3.getObject(params, (err, data) => {
            if (err) {
                console.log(err);
                const message = `Error getting object ${key} from bucket ${bucket}. Make sure they exist and your bucket is in the same region as this function.`;
                console.log(message);
                fail(message);
            } else {
                var result = JSON.parse(data.Body.toString());
//                console.log({result:JSON.stringify(result)});
                if (success == sendResponse)
                    success(result);
                else
                    success(result,id);
            }
        });
    }
    
    function getAccountConfig(success, credentials) {
        var key = "dashboard/config/accounts.json";
        var params = { Bucket: bucket, Key: key };
        console.log({params:params});
        s3.getObject(params, (err,data) => {
            if (err) {
                console.log(err);
            } else {
                var result = JSON.parse(data.Body.toString());
                success(credentials,result);
            }
        });
    }
    
    function authenticate(credentials, data) {
        var crypto = require('crypto');
        var password = crypto.createHash('md5').update(credentials.password).digest("hex");
        console.log({password:password});
        if (data.accounts[credentials.username] && data.accounts[credentials.username].password == password ) {
           data.token = { start:(new Date()).getTime(), key:'123456789' };
           sendAccount(credentials, data);
        } else {
           sendResponse(null);
        }
    }
    
    function sendAccount(credentials, data) {
        console.log({credentials:credentials, data:data});
        if (data.accounts[credentials.username]) {
           var account = {
               info: data.accounts[credentials.username].info,
               orgs: data.organizations.filter(function(org) { return org.users.indexOf(credentials.username) >= 0 }),
               token: data.token
           };
           console.log ({ account:account });
           sendResponse({ account:account }); 
        } else {
           sendResponse(null);
        }
    }
    
    function updateConfig(config, id) {
        var key = "dashboard/config/" + id + ".json";
        const params = { Bucket: bucket, Key: key };
        var data = event.data;
        Object.keys(data).map(function(key) {
            config[key] = data[key];
        });
        config = genCode(config);
        var upload = Object.assign({}, params);
        upload.Body = JSON.stringify(config);
        s3.upload(upload, function(err, data) {
          console.log(err, data);
          sendResponse(data);
        });
    }
    
    function targetSet(val) {
        val = ""+val;
        if (val.indexOf('|') < 0)
            value = !isNaN(val) ? +val : val;
        else
            value = val.split('|');
        return value;
    }
    
    function genCode(config) {
        var codes, spec, code, group, action, step, ruleStep, rule, ruleGroups, index;
        config.code = { groups:{}, actions:{} };
        // It should show up as:
        //      "group": [ ["param1", "param2", "param3"],["param1", "param2", "param3"],["param1", "param2", "param3"] ]
        Object.keys(config.groups).map((group, index) => {
            spec = config.groups[group].criteria;
            config.code.groups[group] = processSpec(config, spec);
        });
        Object.keys(config.actions).map((action, index) => {
            config.code.actions[action] = [];
            config.actions[action].steps.map((step, index) => {
                ruleItems = [];
                if (step.active) {
                    spec = step.where.concat(step.when);
                    code = processSpec(config, spec);
                    if (!code) code = [];   // TO-DO: is there any reason to distinguish [] from null?
                    step.rules.map((rule,index) => {
                        ruleGroups = [];
                        rule.groups.map((group,index) => {
                            if (config.code.groups[group])
                                ruleGroups.push(code.concat(config.code.groups[group]));    // if we've defined group (it's not disabled), add group
                        });
                        if (! rule.groups.length)                                           // there is no group spec, so just use when/where
                            ruleGroups.push(code);
                        rule.type = step.type;
                        ruleItems.push({ criteria:ruleGroups, rule:rule });                 // end with array of all possible first-match criteria, along with the rule what
                    });
                    ruleStep = { stepId:step.id, rules:ruleItems, rulePick:step.rulePick||'first' };
                }
                if (ruleItems.length) config.code.actions[action].push( ruleStep );        // add steps to action list for each step
            });

        });
                
        return config;
    }
    
    function processSpec(config, criteria) {
        var code, codes;
        codes = [];
        criteria.map((steps, index) => {
            code = [];
            // loop through all the criteria for this group definition
            if (steps.active) {
                params = steps.params;
                    
                subject = "";
                switch (params[0]) {
                    case "viewed-uri":
                        subject = "uri";
                        break;
                    case "query":
                        subject = "query";
                        break;
                    case "viewed-page-hostname":
                        subject = "host";
                        break;
                    case "referring-page-url":
                        subject = "referrer";
                        break;
                    case "entry-page-uri":
                        subject = "session-entry-uri";
                        break;
                    case "entry-page-hostname":
                        subject = "session-entry-hostname";
                        break;
                    case "entry-referring-page-url":
                        subject = "session-entry-referrer";
                        break;
                        
                    case "country": case "zip": case "state":
                        subject = "geo_" + params[0];
                        break;
                    case "clientIp":
                        subject = "clientIp";
                        break;
                    case "city-state":
                        subject = "geo_city";
                        // TO-DO split city/state by comma?
                        break;
                    case "distance":
                        subject = "distance";
                        break;

                    case "sessions-count":
                        subject = "counter_session";
                        break;
                    case "page-view-count":
                        subject = "counter_view";
                        break;
                    case "duration":
                        subject = "session_duration";
                        break;
                    
                    case "hour-of-day":
                        subject = "hourofday";
                        break;
                    case "time-of-day":
                        subject = "timeofday";
                        break;
                    case "day-of-week":
                        subject = "dayofweek";
                        break;
                    case "date-of-month":
                        subject = "dateofmonth";
                        break;
                        
                    case "device-type":
                        subject = "device_type";
                        break;
                    case "device-os":
                        subject = "device_os";
                        break;
                    case "device-browser":
                        subject = "device_browser";
                        break;
                    case "device-version":
                        subject = "device_version";
                        break;
                    case "device-platform":
                        subject = "device_platform";
                        break;

                    case "profile-attribute":    
                        subject = "profile-attribute";
			break;
                    
                }
            
                switch (subject) {
                    case "uri": case "host": case "referrer": case "query": case "session-entry-uri": case "session-entry-hostname": case "session-entry-referrer":
                    case "geo_country": case "geo_zip": case "geo_state": case "geo_city": case "clientIp":
                    case "device_type": case "device_os": case "device_browser": case "device_version": case "device_platform":
                        switch (params[1]) {
                            case "current-page":
                                code.push (subject);
                                break;
                            case "previous-page":
                                code.push ([ "lastview", subject ]);
                                break;
                            case "current-session":
                                code.push (subject); // TO-DO
                                break;
                            case "previous-session":
                                code.push (subject); // TO-DO
                                break;
                        }
                        code.push(params[2]);
                        code.push(targetSet(params[3]));
                        break;
                        
                    case "distance":
                        switch(params[2]) {
                            case "current-session":
                                // params1 = ref to location
                                var location = config.settings.locations.filter((l) => l.id==params[1]);
                                if (location && location.length) {
                                    var geo = location[0].coordinates;
                                    code.push([ "distance", [geo[0], geo[1]]]);
                                }
                                break;
                            case "previous-session":
                                // TO-DO
                                break;
                            case "first-session":
                                // TO-DO
                                break;
                        }
                        code.push(params[3]);
                        code.push(targetSet(params[4]));

                        break;
                        
                    case "counter_session":
                        code.push (subject);
                        code.push (params[1]);
                        code.push (targetSet(params[2]));
                        break;
                    case "counter_view": case "session_duration":
                        switch (params[1]) {
                            case "current-session":
                                code.push (subject);
                                break;
                            case "previous-session":
                                code.push (subject);   // TO-DO
                                break;
                            case "first-session":
                                code.push (subject);   // TO-DO
                                break;
                        }
                        code.push (params[2]);
                        code.push (targetSet(params[3]));
                        break;
                    
                    case "hourofday": case "timeofday": case "dayofweek": case "dateofmonth":
                        switch (params[1]) {
                            case "current-session-start": 
                                code.push ([ subject, "sessionStartTime" ]);
                                break;
                            case "previous-session-start":
                                // TO-DO
                                break;
                            case "previous-session-end":
                                // TO-DO
                                break;
                            case "first-session-start":
                                // TO-DO
                                break;
                            case "first-session-end":
                                // TO-DO
                                break;
                            case "current-page":
                                code.push ([ subject ]);
                                break;
                            case "previous-page":
                                code.push ([subject, ["lastview", "timestamp"]]);
                                break;
                        }
                        code.push(params[2]);
                        code.push(targetSet(params[3]));
                        break;

                    case "profile-attribute":
			code.push(params[1]);
			code.push(params[2]);
                        code.push(targetSet(params[3]));
			break;

                }
                codes.push (code);
            }
            
        });
        if (codes.length)
            return codes;
                
    }
    
    function sendResponse(response) {
        callback(null, {
            statusCode: '200',
            body: JSON.stringify({'data':response}),
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
        });
    }
    
};



